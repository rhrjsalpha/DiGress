import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from Graphormer.GP5.data_prepare.Dataloader_2 import SMILESDataset, collate_fn
from graphormer import GraphormerModel
import os
from Graphormer.GP5.Custom_Loss.custom_loss import fastdtw_loss, SoftDTWLoss
#SoftDTWLoss gamma: 부드러움 정도를 제어. 값이 작으면 기존 DTW와 유사, 값이 크면 더 부드럽게 작동. normalize: 정규화 여부 (True/False).


os.environ["CUDA_LAUNCH_BLOCKING"] = "1"
# Configuration dictionary for GraphormerModel

config = {
    "num_atoms": 100,
    "num_in_degree": 10,
    "num_out_degree": 10,
    "num_edges": 50,
    "num_spatial": 100, # 만약 분자에서 계산된 값이 이것보다 더 크면 오류남
    "num_edge_dis": 10,
    "edge_type": "multi_hop",
    "multi_hop_max_dist": 5,
    "num_encoder_layers": 6,
    "embedding_dim": 128,
    "ffn_embedding_dim": 256,
    "num_attention_heads": 8,
    "dropout": 0.1,
    "attention_dropout": 0.1,
    "activation_dropout": 0.1,
    "activation_fn": "gelu",
    "pre_layernorm": False,
    "q_noise": 0.0,
    "qn_block_size": 8,
    "output_size":100,
}

target_type = 'default' # 'default' "ex_prob" "nm_distribution"

# Initialize dataset and DataLoader
dataset = SMILESDataset(csv_file="../../data/data_example.csv", attn_bias_w=1.0,target_type=target_type)  # Include edge weight
#  DataLoader가 생성한 데이터 배치로, 보통 (input_data, target) 형태의 튜플
dataloader = DataLoader(
    dataset,
    batch_size=2,
    collate_fn=lambda batch: collate_fn(batch, dataset, n_pairs=1)
)

# Initialize the model, loss function, and optimizer
model = GraphormerModel(config)

# 손실 함수 정의 두개에 대해서 다르게
# nn.SmoothL1Loss() nn.L1Loss() nn.MSELoss() log_cosh_loss(outputs_prob, targets_prob)
# fastdtw_loss()
criterion = nn.MSELoss()
criterion_ex = SoftDTWLoss(gamma=1.0)  # For 'ex' part
criterion_prob = nn.L1Loss()  # For 'prob' part (예: Binary Cross Entropy)

optimizer = optim.Adam(model.parameters(), lr=0.001)

def move_to_device(batch, device):
    """
    Move batch data to the specified device.
    """
    return {k: v.to(device) for k, v in batch.items() if isinstance(v, torch.Tensor)}

# Training loop
num_epochs = 10
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

for epoch in range(num_epochs):
    model.train()
    total_loss = 0.0
    for batch in dataloader:
        # Move batch data to the device
        batch = move_to_device(batch, device)

        # Extract inputs and targets
        batched_data = {
            "x": batch["x"],
            "adj": batch["adj"],
            "in_degree": batch["in_degree"],
            "out_degree": batch["out_degree"],
            "spatial_pos": batch["spatial_pos"],
            "attn_bias": batch["attn_bias"],
            "edge_input": batch["edge_input"],
            "attn_edge_type": batch["attn_edge_type"],
        }
        targets = batch["targets"]

        # Forward pass
        outputs = model(batched_data, targets=targets, target_type=target_type)
        print("target.shape", targets.shape)
        print("outputs.shape",outputs.shape)
        # Compute loss
        if target_type == "ex_prob":
            # Outputs for 'ex_prob' are 3D: [batch_size, num_pairs, 2]
            outputs_ex = outputs[:, :, 0]  # First part for 'ex'
            outputs_prob = outputs[:, :, 1]  # Second part for 'prob'
            targets_ex = targets[:, :, 0]
            targets_prob = targets[:, :, 1]

            # Compute individual losses
            loss_ex = criterion_ex(outputs_ex, targets_ex)
            loss_prob = criterion_prob(outputs_prob, targets_prob)
            loss = loss_ex + loss_prob



        elif target_type == "default":
            # Outputs for 'default' are 2D: [batch_size, num_features]
            outputs_ex = outputs[:, :outputs.size(1) // 2]  # First half for 'ex'
            outputs_prob = outputs[:, outputs.size(1) // 2:]  # Second half for 'prob'
            print("default targets.shape", targets.shape)

            # Corresponding targets split for 'ex' and 'prob'
            targets_ex = targets[:, :targets.size(1) // 2]  # First half for 'ex'
            targets_prob = targets[:, targets.size(1) // 2:]  # Second half for 'prob'

            # Compute individual losses using different loss functions
            loss_ex = criterion_ex(outputs_ex, targets_ex)  # Loss for 'ex'
            loss_prob = criterion_prob(outputs_prob, targets_prob)  # Loss for 'prob'

            # Combine the losses
            loss = loss_ex + loss_prob

        elif target_type == "nm_distribution":
            loss = criterion(outputs, targets)

        else:
            raise ValueError("Invalid target type")

        # Backward pass and optimization
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    print(f"Epoch [{epoch + 1}/{num_epochs}], Loss: {total_loss / len(dataloader):.4f}")

print("Training complete.")

# [[eV_1,Osc_1] [eV_2,Osc_2].. [eV_50, Osc_50]] 이런 형태로 학습이 진행됨



